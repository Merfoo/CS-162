#pragma once

double avg(double data[], int len);
