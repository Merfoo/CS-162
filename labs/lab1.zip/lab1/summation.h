#pragma once

double sum(double data[], int len);
